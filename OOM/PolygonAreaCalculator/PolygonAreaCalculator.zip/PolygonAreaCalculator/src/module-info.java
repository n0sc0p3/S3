module PolygonAreaCalculator {
	requires java.desktop;
}
